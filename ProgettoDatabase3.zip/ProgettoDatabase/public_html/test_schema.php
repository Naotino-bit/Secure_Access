<?php
require 'public_html/db_connection.php';

$tables = ['Tasks'];
foreach ($tables as $table) {
    echo "Table: $table\n";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo " - " . $row['Field'] . " (" . $row['Type'] . ")\n";
        }
    } else {
        echo " - Table not found.\n";
    }
    echo "\n";
}
?>
