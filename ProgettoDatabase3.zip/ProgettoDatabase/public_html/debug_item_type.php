<?php
require "db_connection.php";
$result = $conn->query("SELECT IdItem FROM Inventory LIMIT 1");
$row = $result->fetch_assoc();
var_dump($row);
?>
