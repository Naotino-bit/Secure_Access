<?php
require "db_connection.php";
session_start();

$message = "";
$access_granted = null;


if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['user']; 

// Recupero dati utente e LIVELLO BADGE
$query = "
    SELECT U.Name, U.Surname, U.IdBadge, B.BadgeLevel, B.ExpirationDate, B.DateOfIssue
    FROM Users U JOIN Badges B ON U.IdBadge = B.IdBadge WHERE U.Email = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$badge = $result->fetch_assoc();

$currentUser = null;
$badgeLevel = 0;

$stmt->close();

$isAdmin = isset($badge['BadgeLevel']) && (int)$badge['BadgeLevel'] === 4;

// Per l'ADMIN in sola visualizzazione (richiesta GET) evitiamo query pesanti sulla tabella Accesses
if ($isAdmin && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $LastPos = 1;              // Valore neutro, la posizione admin non è rilevante
    $LastPositionResult = null;
} else {
    // 2. Troviamo l'ultima posizione dell'utente; se non esiste è fuori dalla struttura
    $LastPositionQuery = $conn->prepare("SELECT IdSectorTo 
                                         FROM Accesses 
                                         WHERE IdBadge = ? AND RESULT = 'GRANTED' 
                                         ORDER BY IdAccess DESC 
                                         LIMIT 1;");
    $LastPositionQuery->bind_param("i", $badge['IdBadge']);
    $LastPositionQuery->execute();
    $LastPositionResult = $LastPositionQuery->get_result();
    $row = $LastPositionResult->fetch_assoc();
    if (!$row) { 
        // Appena entrato nella struttura, sei nella hall
        $LastPos = 1;
    } else {
        $LastPos = $row["IdSectorTo"];
    }

    $LastPositionQuery->close();
}

// 3. Recupero tutte le posizioni dove l'utente può andare (solo se non è admin viewer)
$accessibleSectors = [];
if (!($isAdmin && $_SERVER['REQUEST_METHOD'] !== 'POST')) {
    // Con due join recupero anche i nomi delle stanze
    $PossiblePositionQuery = $conn->prepare("SELECT g.IdGate, g.SecurityLevel, g.IdSectorA, sa.Description 
                                                    AS SectorA_Description, g.IdSectorB, sb.Description 
                                                    AS SectorB_Description 
                                                    FROM Gates g 
                                                    LEFT JOIN Sectors sa ON g.IdSectorA = sa.IdSector 
                                                    LEFT JOIN Sectors sb ON g.IdSectorB = sb.IdSector 
                                                    WHERE (IdSectorA = ? OR IdSectorB = ?) AND SecurityLevel <= ?;");
    $PossiblePositionQuery->bind_param("iii", $LastPos, $LastPos, $badge['BadgeLevel']);
    $PossiblePositionQuery->execute();
    $PossiblePositionResult = $PossiblePositionQuery->get_result();

    // Costruisco l'array dei settori raggiungibili
    $PossiblePositionResult->data_seek(0); 
    while($row = $PossiblePositionResult->fetch_assoc()) {
        if ($LastPos == $row['IdSectorA']){
            $IdSectorTo = $row['IdSectorB']; 
        } else {
            $IdSectorTo = $row['IdSectorA'];
        }
        $accessibleSectors[] = (string)$IdSectorTo;
    }

    // Rimetti il puntatore all'inizio se dovessi riutilizzare il risultato altrove
    $PossiblePositionResult->data_seek(0);
} else {
    $PossiblePositionResult = null;
}

// Assumiamo che $conn, $badge, $LastPos siano già definiti sopra; per $PossiblePositionResult
// vale solo per le richieste non-admin / POST.

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // === 1. GESTIONE JSON INVECE DI POST STANDARD ===
    $json_data = file_get_contents('php://input');
    $request_data = json_decode($json_data, true);
    
    // I dati sono inviati da JS come: { sector_id : room.id }
    $clicked_sector_id = $request_data['sector_id'] ?? null;
    
    // Preparo la risposta JSON di default
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'Errore sconosciuto.'];
    
    // === 2. TROVA IL GATE ASSOCIATO ALLA STANZA CLICCATA ===
    // Dobbiamo trovare TUTTI i gate collegati alla posizione corrente, INDIPENDENTEMENTE dal livello del badge
    // per poter distinguere tra "Non esiste passaggio" (Not Reachable) e "Passaggio esiste ma livello basso" (LOW_LEVEL).
    
    $AllGatesQuery = $conn->prepare("SELECT g.IdGate, g.SecurityLevel, g.IdSectorA, g.IdSectorB 
                                     FROM Gates g 
                                     WHERE (IdSectorA = ? OR IdSectorB = ?)");
    $AllGatesQuery->bind_param("ii", $LastPos, $LastPos);
    $AllGatesQuery->execute();
    $AllGatesResult = $AllGatesQuery->get_result();

    $PossibleGates = [];
    while($row = $AllGatesResult->fetch_assoc()) {
        if ($LastPos == $row['IdSectorA']){
            $IdSectorTo = $row['IdSectorB']; 
        } else {
            $IdSectorTo = $row['IdSectorA'];
        }
        $PossibleGates[$IdSectorTo] = [
            'gate' => $row['IdGate'], 
            'level' => $row['SecurityLevel'] 
        ];
    }
    $AllGatesQuery->close();


    // === 3. ESECUZIONE LOGICA DI CONTROLLO ===

    if (isset($PossibleGates[$clicked_sector_id])) {
        $GateInfo = $PossibleGates[$clicked_sector_id];
        $GateId = $GateInfo['gate'];
        $GateLevel = $GateInfo['level'];
        $SectorId = $clicked_sector_id; // Questo è il settore di destinazione
        
        // *** Esegui la tua logica di controllo (Badge Scaduto, Livello Insufficiente, etc.) ***

        if (!$badge) {
            $response['message'] = "ERRORE: Badge non esistente!";
            $esito = "NOT_FOUND";
        } elseif ($badge['ExpirationDate'] != NULL && new DateTime() > new DateTime($badge['ExpirationDate'])) {
            $response['message'] = "ACCESSO NEGATO: Badge Scaduto!";
            $esito = "EXPIRED";
        } elseif ($badge['BadgeLevel'] == 1 && $LastPos == 1 && $SectorId != 1) {
            // BLOCCO UTENTI PENDING (LEVEL 1) NELLA HALL
            $response['message'] = "ACCESSO NEGATO: Utente in attesa di assunzione. Sei confinato nella Hall fino all'assegnazione di un ruolo.";
            $esito = "LOW_LEVEL"; 
        } elseif ($badge['BadgeLevel'] >= $GateLevel) { // Usiamo il livello del gate
            $response['status'] = 'success';
            $response['message'] = "ACCESSO CONSENTITO: Benvenuto nella Stanza $SectorId.";
            $esito = "GRANTED";
        } else {
            $response['message'] = "ACCESSO NEGATO: Livello insufficiente per questa zona (Gate Level: $GateLevel).";
            $esito = "LOW_LEVEL";
        }
        
        // === 4. LOG DEGLI ACCESSI & BUSINESS LOGIC ===
        if (isset($GateId) && isset($SectorId)) {
            $timestamp = date("Y-m-d H:i:s");
            // Nota: IdSectorTo è il SectorId cliccato.
            $GateWear = $conn->query("SELECT Wear FROM Gates WHERE IdGate = $GateId")->fetch_assoc();
            if ($GateWear['Wear'] >= 100) {
                $response['status'] = 'error';
            $response['message'] = "ACCESSO NEGATO: Manutenzione richiesta su questa porta.";
                $esito = "REQUIRED_MAINTENANCE";
            }
            $logStmt = $conn->prepare("INSERT INTO Accesses (Time, Result, IdGate, IdBadge, IdSectorTo) VALUES (?, ?, ?, ?, ?)");
            $logStmt->bind_param("ssiii", $timestamp, $esito, $GateId, $badge['IdBadge'], $SectorId);
            $logStmt->execute();
            $idAccess = $logStmt->insert_id; // Recupero ID dell'accesso appena creato
            $logStmt->close();

            // A. GESTIONE WARNINGS (Tentativo non autorizzato)
            if ($esito == "LOW_LEVEL") {
                $warnStmt = $conn->prepare("INSERT INTO Warnings (Reason, IdAccess) VALUES ('Tentativo accesso non autorizzato: Livello insufficiente', ?)");
                $warnStmt->bind_param("i", $idAccess);
                $warnStmt->execute();
                $warnStmt->close();
            }

            // B. GESTIONE USURA & MANUTENZIONE (Solo su accesso riuscito)
            if ($esito == "GRANTED") {
                // 1. Incrementa USURA
                $wearStmt = $conn->prepare("UPDATE Gates SET Wear = Wear + 1 WHERE IdGate = ?");
                $wearStmt->bind_param("i", $GateId);
                $wearStmt->execute();
                $wearStmt->close();

                // 2. Controllo Soglia Manutenzione (es. ogni 100 utilizzi)
                // Recupero il nuovo valore di Wear
                $checkWear = $conn->query("SELECT Wear FROM Gates WHERE IdGate = $GateId")->fetch_assoc();
                $currentWear = $checkWear['Wear'];

                if ($currentWear >= 100) {
                    // FIX DUPLICATI: Controlla Pending o Assigned
                    $checkReq = $conn->query("SELECT IdRequest FROM MaintenanceRequests WHERE IdGate = $GateId AND Status IN ('Pending', 'Assigned')");
                    
                    if ($checkReq->num_rows == 0) {
                        // Inseriamo richiesta se usura è alta
                        // STATUS = Pending (come richiesto)
                        // PRIORITY = High
                        // NON RESETTIAMO USURA QUI! (Il reset avverrà alla riparazione)
                        
                        $maintStmt = $conn->prepare("INSERT INTO MaintenanceRequests (Priority, Status, CreatedAt, IdGate) VALUES ('High', 'Pending', NOW(), ?)");
                        $maintStmt->bind_param("i", $GateId);
                        $maintStmt->execute();
                        $maintStmt->close();
                    } else {
                        $maintStmt = $conn->prepare("UPDATE MaintenanceRequests SET Priority = 'High', CreatedAt = NOW() WHERE IdGate = ? AND Status = 'Pending'");
                        $maintStmt->bind_param("i", $GateId);
                        $maintStmt->execute();
                        $maintStmt->close();
                    }
                } elseif ($currentWear >= 66) {
                    // FIX DUPLICATI: Controlla Pending o Assigned
                    $checkReq = $conn->query("SELECT IdRequest FROM MaintenanceRequests WHERE IdGate = $GateId AND Status IN ('Pending', 'Assigned')");
                    
                    if ($checkReq->num_rows == 0) {
                        // Inseriamo richiesta se usura è alta
                        // STATUS = Pending (come richiesto)
                        // PRIORITY = High
                        // NON RESETTIAMO USURA QUI! (Il reset avverrà alla riparazione)
                        
                        $maintStmt = $conn->prepare("INSERT INTO MaintenanceRequests (Priority, Status, CreatedAt, IdGate) VALUES ('Medium', 'Pending', NOW(), ?)");
                        $maintStmt->bind_param("i", $GateId);
                        $maintStmt->execute();
                        $maintStmt->close();
                    } else {
                        $maintStmt = $conn->prepare("UPDATE MaintenanceRequests SET Priority = 'Medium', CreatedAt = NOW() WHERE IdGate = ? AND Status = 'Pending'");
                        $maintStmt->bind_param("i", $GateId);
                        $maintStmt->execute();
                        $maintStmt->close();
                    }
                } elseif ($currentWear >= 33) {
                    // FIX DUPLICATI: Controlla Pending o Assigned
                    $checkReq = $conn->query("SELECT IdRequest FROM MaintenanceRequests WHERE IdGate = $GateId AND Status IN ('Pending', 'Assigned')");
                    
                    if ($checkReq->num_rows == 0) {
                        // Inseriamo richiesta se usura è alta
                        // STATUS = Pending (come richiesto)
                        // PRIORITY = High
                        // NON RESETTIAMO USURA QUI! (Il reset avverrà alla riparazione)
                        
                        $maintStmt = $conn->prepare("INSERT INTO MaintenanceRequests (Priority, Status, CreatedAt, IdGate) VALUES ('Low', 'Pending', NOW(), ?)");
                        $maintStmt->bind_param("i", $GateId);
                        $maintStmt->execute();
                        $maintStmt->close();
                    }
                }
                
            }
        }
        
        // Se l'accesso è GRANTED, aggiorna la posizione dell'utente (opzionale, ma consigliato)
        // Se vuoi aggiornare la posizione e ricaricare la pagina, puoi farlo qui.
        // Ma per una risposta AJAX, generalmente si aggiorna la UI tramite JS.
        if ($esito == "GRANTED") {
            // Invia al client la nuova posizione per aggiornare la UI
            $response['new_pos'] = $SectorId;

            // Calcola le nuove stanze raggiungibili dalla nuova posizione (senza ricaricare la pagina)
            $nextAccessible = [];
            $nextQuery = $conn->prepare("SELECT g.IdGate, g.SecurityLevel, g.IdSectorA, g.IdSectorB 
                                         FROM Gates g 
                                         WHERE (IdSectorA = ? OR IdSectorB = ?) AND SecurityLevel <= ?;");
            $nextQuery->bind_param("iii", $SectorId, $SectorId, $badge['BadgeLevel']);
            $nextQuery->execute();
            $nextResult = $nextQuery->get_result();
            while ($nrow = $nextResult->fetch_assoc()) {
                if ($SectorId == $nrow['IdSectorA']) {
                    $to = $nrow['IdSectorB'];
                } else {
                    $to = $nrow['IdSectorA'];
                }
                $nextAccessible[] = (string)$to;
            }
            $nextQuery->close();

            $response['accessible_sectors'] = $nextAccessible;
        }


    } else {
        $response['message'] = "ERRORE: La stanza $clicked_sector_id non è raggiungibile dalla tua posizione attuale ($LastPos) o non esiste un gate associato.";
    }

    // === 5. RITORNA LA RISPOSTA JSON E TERMINA ===
    echo json_encode($response);
    exit(); // Termina lo script PHP per non stampare il resto dell'HTML
}


// 3. REGISTRIAMO IL LOG NEL DB (esempio commentato)
//$logStmt = $conn->prepare("INSERT INTO Accesses (Time, Result, IdGate, IdBadge) VALUES (?, ?, ?, ?)");
//$logStmt->bind_param("ssii", $timestamp, $esito, $gateId, $badgeId);
//$logStmt->execute();
//$logStmt->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Simulazione Varco</title>
    <style>
        body { font-family: sans-serif; text-align: center; padding: 50px; background-color: #d9d9d9; color: white; }
        .scanner-box { background: #444; padding: 30px; border-radius: 10px; display: inline-block; width: 400px; }
        select, input { width: 90%; padding: 10px; margin: 10px 0; font-size: 1.1em; border-radius: 5px; border: none; }
        button { width: 95%; padding: 10px; font-size: 1.2em; cursor: pointer; background-color: #007bff; color: white; border: none; margin-top: 15px; border-radius: 5px; }
        .result { margin-top: 20px; padding: 20px; font-size: 1.5em; border-radius: 5px; }
        .success { background-color: #28a745; }
        .error { background-color: #dc3545; }
        a { color: #ccc; text-decoration: none; display: block; margin-top: 20px; }


        /* 1. Contenitore principale: Fissato e centrato nel viewport */
        .fixed-centered-overlay {
            /* Posizionamento fisso: rimane fermo durante lo scroll e lo zoom */
            position: fixed; 
            
            /* Sposta il punto d'inizio nell'angolo centrale (50% x 50%) */
            top: 50%;
            left: 50%;
            
            /* Sposta l'elemento indietro della metà della sua dimensione: centramento perfetto */
            transform: translate(-50%, -50%);
            
            /* Assicura che l'elemento sia sempre sopra il resto del contenuto */
            z-index: 9999; 
            
            /* Opzionale: per vedere l'area del contenitore */
            /* border: 1px solid blue; */
        }

        .fixed-centered-overlay svg path:hover {
            fill: red;
            fill-opacity: 0.3;
        }

        /* 2. Elementi interni: Sovrapposti con precisione */
        .overlay-element {
            /* Rimuove gli spazi extra che il browser potrebbe inserire */
            display: block; 
            
            /* Permette a entrambi gli elementi di sovrapporsi con precisione */
            position: absolute;
            
            /* Centramento perfetto rispetto al contenitore .fixed-centered-overlay */
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* 3. Stratificazione */
        .base-layer {
            z-index: 10; /* Livello inferiore */
            width: 1250px; /* Esempio: imposta la dimensione del tuo PNG */
            height: auto;
        }

        .top-layer {
            z-index: 20; /* Livello superiore (apparirà sopra il PNG) */
            width: 640px; /* Esempio: imposta la dimensione del tuo SVG */
            height: auto;
            top: -7px;
        }

        /* Stili dinamici aggiunti da JS */
        .room.accessible:hover {
            fill: #28a745; /* Verde per accesso consentito */
            fill-opacity: 0.5;
        }

        .room.inaccessible:hover {
            fill: #dc3545; /* Rosso per accesso negato */
            fill-opacity: 0.5;
        }

        /* NUOVA CLASSE: Stile della STANZA CORRENTE */
        .room.current-position {
            fill: gold; /* Colore giallo fisso per la posizione attuale */
            fill-opacity: 0.4;
            cursor: default; /* Non sembra cliccabile */
        }
        /* Override per impedire all'hover di cambiare la stanza corrente */
        .room.current-position:hover {
            fill: gold; 
            fill-opacity: 0.4;
        }

    </style>
</head>
<body>

    <h1>Simulazione Controllo Accessi</h1>
    <div id="access-message" class="result"></div>
    <p id="current-pos-text" data-current-pos="<?php echo $LastPos; ?>">
        Ti trovi nella stanza: <?php echo $LastPos;?>
    </p>
    <div class="fixed-centered-overlay">
        <img src="img/piantina2.png" class="overlay-element base-layer" alt=""> 
        
        <svg class="overlay-element top-layer" width="2097" height="2171" viewBox="0 0 2097 2171" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path class="room" id="1" d="M845.713 1459.5L643.713 1812.5L744.713 1984.5L907.713 1886.5H987.713V2163.5H1109.71V1897.5H1173.71V1601.5H1338.71L1253.71 1459.5H845.713Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="2" d="M915.213 1895L748.213 1992.5L847.213 2162H987.713V1895H915.213Z" fill="red" str fill-opacity="0"oke="black"/>
            <path class="room" id="3" d="M1178.71 1901H1114.71V2170H1260.1L1466.21 1813H1178.71V1901Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="4" d="M1464.71 1810H1179.71V1609.08H1348.71L1464.71 1810Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="5" d="M290.253 1451L704.213 1690L765.33 1583L541.896 1454.5L765.33 1325.5L701.213 1214.45L438.713 1366L479.713 1091.5H356.213L290.253 1451Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="6" d="M632.72 1812L701.713 1692.5L549.456 1602L428.213 1812H632.72Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="7" d="M426.713 1811.94L548.213 1601.5L287.713 1448.5H2.3783L212.213 1811.94H426.713Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="8" d="M210.482 1085.5L3.21289 1444.5H290.713L357.213 1085.5H210.482Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="9" d="M628.713 1092.5H482.213L441.713 1360.46L697.995 1212.5L628.713 1092.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="10" d="M768.713 1326.33L546.713 1454.5L762.276 1576.5L837.713 1445.84L768.713 1326.33Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="11" d="M483.213 573.5H89.2129L0.578125 725.5L208.713 1086H632.713L758.713 861.5L534.213 752V696.445L483.213 667V573.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="12" d="M211.436 362L92.2129 568.5H488.713V362H211.436Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="13" d="M632.713 362.5H490.213V665.793L540.713 694.95L753.668 572L632.713 362.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="14" d="M839.213 721.358L754.713 575L536.713 696.5V751.5L759.457 859.5L839.213 721.358Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="15" d="M912.713 595H775.713L844.713 724H1257.23L1331.71 595H1092.71V362.5H912.713V595Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="16" d="M1096.21 420V591.5H1333.2L1432.21 420H1096.21Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="17" d="M912.713 360H640.213L772.713 593.5H912.713V360Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="18" d="M1092.21 357.5H808.213V249.269L723.743 200.5L839.213 0.5H1092.21V357.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="19" d="M634.878 358L723.213 205L806.713 250.5V358H634.878Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="20" d="M1434.21 416.5H1095.71V1.5H1261.01L1467.41 359L1434.21 416.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="21" d="M1427.21 784.5V444L1265.39 723.5L1408.86 972L1471.21 936V889H1818.71V577.5H1765.21V784.5H1427.21Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="22" d="M1474.71 362.424L1430.21 439.5V781H1761.21V362.424H1474.71Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="23" d="M2009.71 575H1765.21V362.824H1887.21L2009.71 575Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="24" d="M2010.71 578.5H1821.71L1820.71 891.151H1998.21L2094.72 724L2010.71 578.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="25" d="M1888.21 1086.5H1773.71V894.242H1999.21L1888.21 1086.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="26" d="M1472.21 941.318L1405.21 980L1472.21 1084H1770.71V894.5H1472.21V941.318Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="27" d="M1397.31 1213.5L1262.21 1447.5L1357.71 1605H1814.21V1283.3H1518.21L1397.31 1213.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="28" d="M1469.21 1089.76L1399.21 1211L1520.21 1280H1723.71V1089.76H1469.21Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="29" d="M1998.21 1280.5H1725.71V1091H1888.81L1998.21 1280.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="30" d="M2001.21 1287H1817.71V1609H2004.68L2095.9 1451L2001.21 1287Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="31" d="M2004.21 1610H1677.71V1812.65H1887.21L2004.21 1610Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="32" d="M1675.71 1610H1359.21L1472.71 1811.5H1675.71V1610Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
            <path class="room" id="33" d="M1254.71 1452.5H844.713L637.866 1088.77L844.713 730.5H1257.87L1464.71 1088.77L1254.71 1452.5Z" fill="#D9D9D9" fill-opacity="0" stroke="black"/>
        </svg>


        

    </div>

    <!--    SCRIPT MAPPA        -->

    <script>
    // 1. Variabile per i settori accessibili
    let accessibleSectors = <?php echo json_encode($accessibleSectors); ?>;
    
    // Funzione per inizializzare gli eventi (chiamata al caricamento e dopo l'accesso GRANTED)
    function initializeMapEvents(currentPos) {
        
        // Prima di tutto, marca la posizione corrente
        document.querySelectorAll('.room').forEach(room => {
            room.classList.remove('current-position'); // Rimuovi la classe da tutti
            if (room.id == currentPos) {
                room.classList.add('current-position'); // Aggiungi la classe alla posizione attuale
            }
        });


        document.querySelectorAll('.room').forEach(room => {
            const roomId = room.id;

            // Rimuovi vecchi listener per evitare duplicati (necessario quando si re-inizializza)
            room.removeEventListener('mouseover', handleMouseOver);
            room.removeEventListener('mouseout', handleMouseOut);
            room.removeEventListener('click', handleClick); 
            
            // Aggiungi i nuovi listener

            // MOUSEOVER (usiamo una funzione esterna per poterla rimuovere)
            room.addEventListener('mouseover', handleMouseOver);

            // MOUSEOUT
            room.addEventListener('mouseout', handleMouseOut);
            
            // CLICK
            room.addEventListener('click', handleClick);
        });
    }


    // Funzione MOUSEOVER (Logica Hover)
    function handleMouseOver() {
        // Recupera la posizione corrente dal DOM (la fonte aggiornata)
        const currentPos = document.getElementById('current-pos-text').dataset.currentPos;
        const roomId = this.id; // 'this' è l'elemento room (path) cliccato

        // NON TOCCARE LA STANZA CORRENTE!
        if (roomId == currentPos) {
            return; 
        }
        
        // CONTROLLO DI ACCESSO (usa l'array 'accessibleSectors' aggiornato)
        if (accessibleSectors.includes(roomId)) {
            this.classList.add('accessible');
            this.classList.remove('inaccessible');
        } else {
            this.classList.add('inaccessible');
            this.classList.remove('accessible');
        }
    }


    // Funzione MOUSEOUT (Ripulisce l'Hover)
    function handleMouseOut() {
        // Rimuove le classi dinamiche, ripristinando lo stato base (trasparente o current-position)
        this.classList.remove('accessible', 'inaccessible');
    }
    
    
    // Funzione CLICK (Logica AJAX)
    function handleClick() {
        const clickedId = this.id;
        const currentPos = document.getElementById('current-pos-text').dataset.currentPos;
        
        // Se si clicca sulla stanza corrente (il click su inaccessibile ora è permesso per generare Warning)
        if (clickedId == currentPos) {
            return;
        }

        // Effettua la chiamata AJAX
        fetch('gates.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sector_id : clickedId }) 
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Errore di rete o del server.');
            }
            return response.json();
        })
        .then(data => {
            
            // 1. Mostra il messaggio di stato
            const resultElement = document.getElementById('access-message'); 
            resultElement.textContent = data.message;
            resultElement.className = data.status === 'success' ? 'result success' : 'result error';

            // 2. GESTIONE ACCESSO CONSENTITO (Aggiornamento Mappa Senza Ricarica)
            if (data.status === 'success' && data.new_pos) {
                
                // a) AGGIORNA LO STATO GLOBALE NELL'HTML
                const posElement = document.getElementById('current-pos-text');
                posElement.textContent = `Ti trovi nella stanza: ${data.new_pos}`;
                posElement.dataset.currentPos = data.new_pos; // *** ESSENZIALE: Aggiorna il data attribute! ***
                
                // b) Rimuovi il messaggio di "Hall" se ci si sposta dalla Hall (Stanza 1)
                if (data.new_pos != '1') {
                    // Puoi rifare la logica PHP qui per il messaggio hall se necessario.
                }

                // c) Aggiorna le posizioni possibili lato client (senza ricaricare tutta la pagina)
                if (Array.isArray(data.accessible_sectors)) {
                    accessibleSectors = data.accessible_sectors.map(String);
                } else {
                    accessibleSectors = [];
                }

                // d) Riesegui il wiring degli eventi con la nuova posizione corrente
                initializeMapEvents(String(data.new_pos));
            }
        })
        .catch(error => {
            console.error('Si è verificato un errore:', error);
            document.getElementById('access-message').textContent = 'Errore di comunicazione con il server.';
            document.getElementById('access-message').className = 'result error';
        });
    }

    // Avvia gli eventi al caricamento della pagina solo per gli utenti NON admin
    const isAdmin = <?php echo $isAdmin ? 'true' : 'false'; ?>;
    if (!isAdmin) {
        initializeMapEvents(<?php echo json_encode($LastPos); ?>);
    }

    // === REALTIME ADMIN OVERLAY (BadgeLevel 4) ===
    if (isAdmin) {
        // Disabilita i click per l'admin: la mappa diventa “monitor” (puoi rimuovere se vuoi mantenerli)
        document.querySelectorAll('.room').forEach(r => r.style.pointerEvents = 'none');

        const svg = document.querySelector('svg.top-layer');
        const overlayGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        overlayGroup.setAttribute('id', 'admin-live-overlay');
        svg.appendChild(overlayGroup);

        // id_badge -> { id_sector, label, color, el }
        const people = new Map();
        // id_sector -> [id_badge, id_badge, ...] (ordine usato per lo stacking verticale)
        const sectorStacks = new Map();
        let lastEventId = 0;

        const palette = [
            '#2563eb', '#16a34a', '#dc2626', '#9333ea', '#ea580c', '#0891b2',
            '#4f46e5', '#65a30d', '#be123c', '#7c3aed', '#b45309', '#0e7490'
        ];
        function colorFor(badgeId) {
            return palette[Math.abs(parseInt(badgeId, 10)) % palette.length];
        }

        function roomCenter(roomId) {
            const room = document.getElementById(String(roomId));
            if (!room || typeof room.getBBox !== 'function') return null;
            const b = room.getBBox();
            return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
        }

        function upsertMarker(p) {
            const center = roomCenter(p.id_sector);
            if (!center) return;

            const key = String(p.id_badge);
            const existing = people.get(key);
            const color = existing?.color || colorFor(p.id_badge);
            const label = `${p.name ?? ''} ${p.surname ?? ''}`.trim() || `Badge ${p.id_badge}`;

            // Aggiorna gli stack per stanza (così, se più persone sono nella stessa stanza,
            // le etichette vengono "impilate" verticalmente invece di sovrapporsi).
            const prevSector = existing?.id_sector;
            if (prevSector != null && prevSector !== p.id_sector) {
                const prevArr = sectorStacks.get(String(prevSector));
                if (prevArr) {
                    sectorStacks.set(
                        String(prevSector),
                        prevArr.filter(id => id !== key)
                    );
                }
            }

            const stackKey = String(p.id_sector);
            let stack = sectorStacks.get(stackKey);
            if (!stack) {
                stack = [];
                sectorStacks.set(stackKey, stack);
            }
            if (!stack.includes(key)) {
                stack.push(key);
            }

            let g = existing?.el;
            if (!g) {
                g = document.createElementNS('http://www.w3.org/2000/svg', 'g');

                // Piccolo "pin" tondo colorato (sempre visibile)
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('r', '14');
                circle.setAttribute('cx', '0');
                circle.setAttribute('cy', '0');
                circle.setAttribute('fill', color);
                circle.setAttribute('fill-opacity', '0.98');
                circle.setAttribute('stroke', '#111827');
                circle.setAttribute('stroke-width', '2.5');

                // Etichetta tipo "pill" (visibile SOLO in hover)
                const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                bg.setAttribute('x', '20');
                bg.setAttribute('y', '-40');
                bg.setAttribute('rx', '12');
                bg.setAttribute('ry', '12');
                // width dinamica calcolata dopo in base alla larghezza del testo
                bg.setAttribute('height', '60');
                bg.setAttribute('fill', '#f9fafb');
                bg.setAttribute('fill-opacity', '0.96');
                bg.setAttribute('stroke', '#111827');
                bg.setAttribute('stroke-width', '1.8');
                bg.setAttribute('opacity', '0');

                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', '32');
                text.setAttribute('y', '6');
                text.setAttribute('font-size', '32');
                text.setAttribute('font-family', 'system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif');
                text.setAttribute('fill', '#111827');
                text.setAttribute('font-weight', '700');
                text.setAttribute('opacity', '0');
                text.textContent = label;

                // Hover: mostra/nasconde label
                g.addEventListener('mouseenter', () => {
                    bg.setAttribute('opacity', '1');
                    text.setAttribute('opacity', '1');
                });
                g.addEventListener('mouseleave', () => {
                    bg.setAttribute('opacity', '0');
                    text.setAttribute('opacity', '0');
                });

                g.appendChild(circle);
                g.appendChild(bg);
                g.appendChild(text);
                overlayGroup.appendChild(g);

                // Imposta larghezza dinamica dell'etichetta in base al testo
                try {
                    const textLen = text.getComputedTextLength();
                    const paddingX = 28;
                    bg.setAttribute('width', String(textLen + paddingX * 2));
                } catch (e) {
                    // fallback: larghezza fissa ragionevole
                    bg.setAttribute('width', '360');
                }
            } else {
                // aggiorna label se cambia (es: snapshot vuota -> stream completa)
                const text = g.querySelector('text');
                const bg = g.querySelector('rect');
                if (text && text.textContent !== label) {
                    text.textContent = label;
                }
                if (text && bg) {
                    try {
                        const textLen = text.getComputedTextLength();
                        const paddingX = 28;
                        bg.setAttribute('width', String(textLen + paddingX * 2));
                    } catch (e) {
                        // lascia dimensioni correnti
                    }
                }
            }

            // Calcola offset verticale in base alla posizione nello stack della stanza
            const index = stack.indexOf(key);
            const n = stack.length || 1;
            const spacing = 40; // distanza verticale tra le etichette
            const offsetY = (index - (n - 1) / 2) * spacing;

            g.setAttribute('transform', `translate(${center.x}, ${center.y + offsetY})`);
            people.set(key, { ...p, label, color, el: g });
        }

        function applySnapshot(list) {
            (list || []).forEach(p => {
                lastEventId = Math.max(lastEventId, p.id_access || 0);
                upsertMarker(p);
            });
        }

        // 1) Snapshot iniziale (tutti)
        fetch('admin_positions_snapshot.php')
            .then(r => r.ok ? r.json() : Promise.reject(r))
            .then(data => applySnapshot(data.positions))
            .catch(() => {
                // niente: se fallisce, continueremo con lo stream
            })
            .finally(() => {
                // 2) Stream realtime (EventSource) con last_id per non perdere eventi
                const es = new EventSource(`admin_positions_stream.php?last_id=${encodeURIComponent(lastEventId)}`);

                es.addEventListener('move', (ev) => {
                    try {
                        const payload = JSON.parse(ev.data);
                        if (payload?.id_access) lastEventId = Math.max(lastEventId, payload.id_access);
                        upsertMarker(payload);
                    } catch (e) {
                        // ignore
                    }
                });

            });
    }
</script>

</body>
</html>
