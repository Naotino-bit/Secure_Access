<?php
require 'db_connection.php';

$result = $conn->query("SHOW TABLES");
while ($row = $result->fetch_array()) {
    echo $row[0] . "\n";
    $currTable = $row[0];
    $desc = $conn->query("DESCRIBE $currTable");
    while ($d = $desc->fetch_assoc()) {
        echo "  - " . $d['Field'] . " " . $d['Type'] . "\n";
    }
}
?>
