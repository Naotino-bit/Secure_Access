<?php
require 'public_html/db_connection.php';

$tables = ['MaintenanceRequests', 'Tasks', 'MaintenanceTasks', 'Inventory', 'Employees', 'Gates'];

foreach ($tables as $table) {
    echo "TABLE: $table\n";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo $row['Field'] . " - " . $row['Type'] . "\n";
        }
    } else {
        echo "Error: " . $conn->error . "\n";
    }
    echo "-------------------\n";
}
?>
